#pragma once

void test_quickSort(int a[], int numOfElem)
{
	/****************************
			TESTING CASES
	*****************************/

	//quickSort_2(a, 0, numOfElem - 1);

	quickSort_3(a, 0, numOfElem - 1);
}
